Config = {}

-- Vehículos disponibles por cada estilo
Config.Vehicles = {
    normal    = { "tailgater", "oracle", "stanier" },
    cuidadoso = { "primo", "washington", "asterope" },
    erratico  = { "sultan", "futo", "blista" },
    agresivo  = { "jugular", "buffalo2", "comet2", "stryder", "faggio", "hakuchou2", "bagger", "manchez", "ratbike", "caddy2", "italigtb", "zentorno", "thrax", "tezeract", "ignus", "taipan", "infernus", "zorrusso", "cyclone", "virtue", "prototipo" }
}


-- Estilos de conducción (flag nativo de GTA V)
Config.DriveStyles = {
    normal    = 786603,        -- Respeta semáforos y tráfico
    cuidadoso = 786603,        -- Muy cuidadoso
    erratico  = 1081,          -- Errático
    agresivo  = 1074528293 + 0x40000 + 0x80000
}


-- Probabilidades (suman 100%)
Config.Probabilidades = {
    normal    = 33, 
    cuidadoso = 33,
    erratico = 1,
    agresivo  = 33
}

-- Nombre del comando
Config.CommandName = "ubor"

-- Velocidad máxima que intentarán usar (en m/s)
-- 80 km/h ≈ 22.22 m/s
-- 60 km/h ≈ 16.66 m/s
-- 250 km/h ≈ 69.44 m/s

Config.MaxSpeed = {
    normal    = 22.22,  -- tranqui (~80 km/h)
    cuidadoso = 16.66,  -- más lento (~60 km/h)
    agresivo  = 69.44   -- al mango 🚀 (~250 km/h)
}


-- Puntos de spawn de los Ubers (usa siempre el más cercano)
Config.SpawnPoints = {
    vector4(382.16, -1065.32, 28.85, 270.7),
    vector4(263.47, -871.72, 28.77, 243.5),
    vector4(-809.61, -62.4, 37.23, 204.33),
    vector4(-1441.9, -67.19, 51.78, 133.54),
    vector4(393.45, 289.41, 102.57, 159.53),
    vector4(-1170.17, -1521.12, 3.97, 33.74),
    vector4(-1057.68, -2641.97, 13.42, 239.77),
    vector4(454.64, -2027.75, 23.67, 227.92),
    vector4(-2193.64, -420.24, 12.68, 318.38),
    vector4(1722.43, -1306.73, 85.33, 55.48),
    vector4(2549.5, 333.59, 108.3, 202.54),
    vector4(1948.19, 2432.93, 54.49, 57.66),
    vector4(1801.9, 3704.66, 33.69, 161.63),
    vector4(2554.74, 4695.45, 33.28, 51.47),
    vector4(1509.03, 4510.74, 52.85, 93.37),
    vector4(-214.73, 3899.47, 36.79, 90.71),
    vector4(1084.85, 2677.55, 38.38, 0.04),
    vector4(-178.79, 1891.31, 197.54, 217.88),
    vector4(-3196.07, 1160.18, 9.15, 251.29),
    vector4(-1362.75, 2450.43, 26.86, 224.15),
    vector4(-2372.58, 4037.7, 29.12, 207.19),
    vector4(-1561.74, 4981.63, 61.05, 210.79),
    vector4(-137.2, 6356.26, 31.08, 44.0),
    vector4(1662.34, 6422.36, 29.63, 130.76),
    vector4(316.41, 5390.14, 647.29, 151.28),
    vector4(-267.74, 419.87, 108.74, 309.01),
    vector4(-1532.31, -712.68, 28.01, 293.18),
    vector4(-396.21, -2139.36, 10.23, 247.41),
    vector4(246.31, -2665.24, 5.61, 328.45),
    vector4(783.98, -2992.1, 5.61, 62.91),
    vector4(1077.23, -2147.7, 31.76, 45.11),
    vector4(933.15, -70.34, 78.35, 118.55),
    vector4(759.45, 6523.6, 25.51, 158.47),
    vector4(26.69, 6434.34, 31.0, 227.15),
    vector4(98.04, -596.6, 31.22, 339.89)
}

-- Tiempo de bloqueo entre pedidos (segundos). 
Config.Cooldown = 120

-- Configuración del blip del Uber
Config.Blip = {
    sprite = 843,     -- Sprite solicitado
    color  = 5,       -- Amarillo
    scale  = 0.8,
    text   = "Ubor en camino"
}

-- Distancia a la que consideramos que el Uber "llegó" a tu ubicación inicial
Config.ArrivalDistance = 2.0

-- Intervalo de chequeo en ms para ver si llegó a tu posición inicial
Config.CheckIntervalMs = 1000

-- Sistema de precios
Config.Pricing = {
    basePrice = 100,             -- Precio base por solicitar el servicio
    pricePerMeter = 0.5,         -- Precio por metro recorrido (si usás cálculo dinámico)
    minPrice = 100,              -- Precio mínimo del viaje
    maxPrice = 5000,             -- Precio máximo del viaje
    finalPrice = 200,            -- 🔹 Precio fijo al llegar al destino
    insufficientFundsTimeout = 5000 -- Tiempo en ms antes de que el Uber se vaya si no tienes dinero (5 segundos)
}

-- Tipo de cuenta para el pago (bank o cash)
Config.PaymentAccount = "bank"

-- Configuración de matones cuando no pagas
Config.Thugs = {
    models = {           -- Peds que pueden spawnear (aleatorio entre ellos)
        "a_m_m_fatlatin_01",
        "g_m_m_chicold_01",
        "g_m_m_armgoon_01"
    },
    weapons = {          -- Armas posibles (aleatorio entre ellas)
        "WEAPON_GOLFCLUB",  -- palo de golf (base)
        -- "WEAPON_BAT",    -- (ejemplo, puedes habilitarlo después)
        -- "WEAPON_KNIFE"
    },
    count = 3            -- Cuántos se spawnean
}
