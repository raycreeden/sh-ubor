local QBCore = exports['qb-core']:GetCoreObject()

-- 🔹 Tabla para trackear viajes activos
local ActiveTrips = {}

-- 🔹 Pago del viaje al finalizar
RegisterNetEvent('sh-ubor:server:PayTrip', function(amount)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local account = Config.PaymentAccount or "bank"
    amount = tonumber(amount) or 0

    if amount <= 0 then return end

    Player.Functions.RemoveMoney(account, amount, "ubor-trip")
    TriggerClientEvent('QBCore:Notify', src, "Pagaste $" .. amount .. " por el viaje Ubor.", "success")
end)

-- 🔹 Forzar pago (cuando muere el jugador sin pagar)
RegisterNetEvent("sh-ubor:server:ForcePay", function(amount)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if Player and amount > 0 then
        Player.Functions.RemoveMoney("bank", amount, "ubor-no-pago")
    end
end)

-- 🔹 Notificación policial (blip + MDT)
RegisterNetEvent("sh-ubor:server:PoliceNotify", function(data)
    local src = source
    if type(data) ~= "table" then return end
    
    local msg = data.msg or "Incidente"
    local x, y, z = tonumber(data.x), tonumber(data.y), tonumber(data.z)
    if not (x and y and z) then return end

    for _, ply in pairs(QBCore.Functions.GetQBPlayers()) do
        local job = ply.PlayerData.job
        if job and job.name == "police" and job.onduty then
            -- Blip personalizado
            TriggerClientEvent("sh-ubor:client:PoliceBlip", ply.PlayerData.source, msg, {x=x, y=y, z=z})
        end
    end

    -- 🔹 Enviar también al MDT del policejob
    TriggerEvent("police:server:policeAlertMessage", {
        title = "Agresión de chofer (Ubor)",
        coords = {x=x, y=y, z=z},
        description = msg
    })
end)

-- 🔹 Forzar pasajero
RegisterNetEvent("sh-ubor:server:ForcePassenger", function(targetId, vehNet)
    local src = source
    if not targetId or not vehNet then return end

    -- Guardar relación viaje
    ActiveTrips[src] = ActiveTrips[src] or { owner = src, passengers = {} }
    table.insert(ActiveTrips[src].passengers, targetId)

    TriggerClientEvent("sh-ubor:client:ForcePassenger", targetId, vehNet)
end)

-- 🔹 Pago fallido o cancelación del dueño
RegisterNetEvent("sh-ubor:server:PaymentFailed", function()
    local src = source
    if ActiveTrips[src] then
        -- limpiar también pasajeros
        for _, id in ipairs(ActiveTrips[src].passengers) do
            TriggerClientEvent("sh-ubor:client:ForceCleanup", id)
        end
        TriggerClientEvent("sh-ubor:client:ForceCleanup", src)
        ActiveTrips[src] = nil
    else
        TriggerClientEvent("sh-ubor:client:ForceCleanup", src)
    end
end)

