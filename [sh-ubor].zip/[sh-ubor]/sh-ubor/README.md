# Qb-core 
# Sistema personalizado de Uber 
# Dependencias - Qb-core , Qb-Banking. 
# poner en "Resources"  poner en " ensure [sh-ubor] " y listo 