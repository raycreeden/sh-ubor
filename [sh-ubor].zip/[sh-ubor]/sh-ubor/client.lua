local QBCore = exports['qb-core']:GetCoreObject()

-- Estado
local activeDriver = nil
local activeVehicle = nil
local activeBlip = nil
local uborInProgress = false
local currentDestination = nil
local currentDriveStyle = nil
local currentSpeed = nil
local waitingForPlayer = false
local showInteraction = false
local travelDistance = 0
local initialPlayerPosition = nil
local hasStartedFinalTrip = false
local pendingPayment = false
local finalTripPrice = 0
local alertSent = false -- 👈 arriba del todo en el archivo

-- Calcular distancia entre dos puntos
local function calculateDistance(coords1, coords2)
    return #(coords1 - coords2)
end

-- Calcular precio dinámico
local function calculateTripPrice(distance)
    local price = Config.Pricing.basePrice + (distance * Config.Pricing.pricePerMeter)
    price = math.max(Config.Pricing.minPrice, math.min(Config.Pricing.maxPrice, price))
    return math.floor(price)
end

-- Verificar si el jugador tiene suficiente dinero (solo visual/client)
local function checkPlayerMoney(amount)
    local playerData = QBCore.Functions.GetPlayerData()
    if not playerData or not playerData.money then return true end
    if Config.PaymentAccount == "bank" then
        return (playerData.money["bank"] or 0) >= amount
    else
        return (playerData.money["cash"] or 0) >= amount
    end
end

-- Elegir tipo según probabilidades
local function elegirTipo()
    local rand = math.random(1, 100)
    local acumulado = 0
    for tipo, prob in pairs(Config.Probabilidades) do
        acumulado = acumulado + prob
        if rand <= acumulado then
            return tipo
        end
    end
    return "normal"
end

-- Spawn más cercano
local function getClosestSpawn()
    local ped = PlayerPedId()
    local pos = GetEntityCoords(ped)
    local closest = nil
    local dist = 1e9

    for _, spawn in ipairs(Config.SpawnPoints) do
        local sPos = vector3(spawn.x, spawn.y, spawn.z)
        local d = #(pos - sPos)
        if d < dist then
            dist = d
            closest = spawn
        end
    end
    return closest
end

-- Crear blip
local function createUberBlip(vehicle)
    if activeBlip and DoesBlipExist(activeBlip) then
        RemoveBlip(activeBlip)
    end
    local blip = AddBlipForEntity(vehicle)
    SetBlipSprite(blip, Config.Blip.sprite)
    SetBlipColour(blip, Config.Blip.color)
    SetBlipScale(blip, Config.Blip.scale)
    SetBlipAsShortRange(blip, false)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(Config.Blip.text)
    EndTextCommandSetBlipName(blip)
    activeBlip = blip
end

-- Tarea de manejo agresiva
local function driveTo(driver, vehicle, x, y, z, speed, driveStyle)
    TaskVehicleDriveToCoordLongrange(driver, vehicle, x, y, z, speed, driveStyle, 10.0)
    SetDriveTaskDrivingStyle(driver, driveStyle)
    SetDriverAggressiveness(driver, 1.0)
end

-- Verificar si jugador está en el Uber
local function isPlayerInUber()
    if not activeVehicle or not DoesEntityExist(activeVehicle) then return false end
    return IsPedInVehicle(PlayerPedId(), activeVehicle, false)
end

-- Forzar al jugador a entrar en el vehículo como pasajero
local function forcePlayerIntoVehicle()
    if not activeVehicle or not DoesEntityExist(activeVehicle) then return false end

    local playerPed = PlayerPedId()
    local vehicleCoords = GetEntityCoords(activeVehicle)
    local playerCoords = GetEntityCoords(playerPed)
    local distance = #(playerCoords - vehicleCoords)

    if distance > 10.0 then return false end

    SetVehicleDoorsLocked(activeVehicle, 0)
    SetVehicleDoorsLockedForAllPlayers(activeVehicle, false)

    -- Lista de asientos posibles (sin el del conductor)
    local seats = {0, 1, 2} -- copiloto, trasero izq, trasero der
    for _, seat in ipairs(seats) do
        if IsVehicleSeatFree(activeVehicle, seat) then
            TaskWarpPedIntoVehicle(playerPed, activeVehicle, seat)
            return true
        end
    end

    return false -- si no hay ninguno libre
end

-- Dibujar texto 3D
local function DrawText3D(x, y, z, text)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    if not onScreen then return end
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x, _y)
    local factor = (string.len(text)) / 370
    DrawRect(_x, _y + 0.0125, 0.015 + factor, 0.03, 41, 11, 41, 68)
end

-- Spawn y lógica principal
local function spawnUber()
    local playerPed = PlayerPedId()
    if not IsWaypointActive() then
        QBCore.Functions.Notify("Marca un destino en el mapa primero.", "error")
        return false
    end
    local waypointBlip = GetFirstBlipInfoId(8)
    if not DoesBlipExist(waypointBlip) then
        QBCore.Functions.Notify("Marca un destino en el mapa primero.", "error")
        return false
    end

    local destino = GetBlipInfoIdCoord(waypointBlip)
    local tipo = elegirTipo()

    -- 🔹 Vehículos: elegir aleatorio si hay lista
    local vehList = Config.Vehicles[tipo]
    local vehModel = "adder" -- fallback por si no hay nada en config
    if vehList then
        if type(vehList) == "table" then
            vehModel = vehList[math.random(1, #vehList)]
        else
            vehModel = vehList
        end
    end

    local vehModelHash = joaat(vehModel)
    local pedModelHash = joaat("a_m_y_business_01")
    local driveStyle = Config.DriveStyles[tipo] or 1074528293
    local speed = Config.MaxSpeed[tipo] or 30

    currentDestination = destino
    currentDriveStyle = driveStyle
    currentSpeed = speed

    local spawn = getClosestSpawn()
    if not spawn then
        QBCore.Functions.Notify("No hay puntos de spawn disponibles.", "error")
        return false
    end

    RequestModel(vehModelHash)
    RequestModel(pedModelHash)
    local timeout = 5000
    local startTime = GetGameTimer()
    while (not HasModelLoaded(vehModelHash) or not HasModelLoaded(pedModelHash)) and (GetGameTimer() - startTime) < timeout do
        Wait(10)
    end
    if not HasModelLoaded(vehModelHash) or not HasModelLoaded(pedModelHash) then
        QBCore.Functions.Notify("Error al cargar modelos.", "error")
        return false
    end

    local veh = CreateVehicle(vehModelHash, spawn.x, spawn.y, spawn.z, spawn.w, true, true)
    if not DoesEntityExist(veh) then
        QBCore.Functions.Notify("No se pudo crear el vehículo.", "error")
        return false
    end

    -- Apagar radio al spawnear
    SetEntityAsMissionEntity(veh, true, true)
    if SetEntityDistanceCullingRadius then
    SetEntityDistanceCullingRadius(veh, 999999.0)
    end
    SetVehRadioStation(veh, "OFF")
    SetVehicleRadioLoud(veh, false)
    SetVehicleOnGroundProperly(veh)
    SetVehicleNeedsToBeHotwired(veh, false)
    SetVehicleEngineOn(veh, true, true, false)
    SetVehicleDoorsLocked(veh, 0)
    SetVehicleDoorsLockedForAllPlayers(veh, false)

    local driver = CreatePedInsideVehicle(veh, 26, pedModelHash, -1, true, false)
    if not DoesEntityExist(driver) then
        DeleteEntity(veh)
        QBCore.Functions.Notify("No se pudo crear el conductor.", "error")
        return false
    end

    SetEntityAsMissionEntity(driver, true, true)
    SetPedKeepTask(driver, true)
    SetBlockingOfNonTemporaryEvents(driver, true)
    SetDriverAbility(driver, 1.0)
    SetDriverAggressiveness(driver, 1.0)

    -- 🔹 Si el tipo es agresivo, activar insultos + fuck you + bocina
if tipo == "agresivo" then
    CreateThread(function()
        while uborInProgress and DoesEntityExist(driver) and DoesEntityExist(veh) do
            -- Insulto cada 5s
            Wait(5000)
            PlayPedAmbientSpeechNative(driver, "GENERIC_INSULT_HIGH", "SPEECH_PARAMS_FORCE_SHOUTED_CLEAR")

            -- Cada tanto también el fuck you (random)
            if math.random(1, 2) == 1 then
                RequestAnimDict("anim@mp_player_intselfiethe_bird")
                while not HasAnimDictLoaded("anim@mp_player_intselfiethe_bird") do
                    Wait(10)
                end
                TaskPlayAnim(driver, "anim@mp_player_intselfiethe_bird", "idle_a", 8.0, -8.0, 2000, 49, 0, false, false, false)
            end

            -- Bocina cada 10s (3 veces seguidas)
            if DoesEntityExist(veh) then
                Wait(5000) -- completar los 10s (5 de insultos + 5 extra)
                for i = 1, 3 do
                    StartVehicleHorn(veh, 200, GetHashKey("NORMAL"), false)
                    Wait(400) -- pausa corta entre bocinazos
                end
            end
        end
    end)
end 

    -- 🔹 Hilo para reponer al conductor si se cae de la moto
    CreateThread(function()
        while uborInProgress and DoesEntityExist(driver) and DoesEntityExist(veh) do
            Wait(2000)

            -- Si es moto y el conductor ya no está en el vehículo
            if IsThisModelABike(GetEntityModel(veh)) then
                if not IsPedInVehicle(driver, veh, false) then
                    -- Forzar que vuelva a subirse
                    -- Forzar que vuelva a subirse
TaskEnterVehicle(driver, veh, -1, -1, 2.0, 16, 0)
Wait(5000) -- darle tiempo a subirse

if IsPedInVehicle(driver, veh, false) then
    -- 🔹 Reanudar viaje si ya estabas en trayecto
    if hasStartedFinalTrip then
        driveTo(driver, veh, currentDestination.x, currentDestination.y, currentDestination.z, currentSpeed, currentDriveStyle)
        QBCore.Functions.Notify("El conductor retomó el viaje tras la caída.", "primary")
    end
else
    QBCore.Functions.Notify("El conductor perdió la moto y canceló el viaje.", "error")
    cleanupUber()
    break
end

                end
            end
        end
    end)

    activeVehicle = veh
    activeDriver = driver
    uborInProgress = true

    createUberBlip(veh)

    local playerPos = GetEntityCoords(playerPed)
    driveTo(driver, veh, playerPos.x, playerPos.y, playerPos.z, speed, driveStyle)
    QBCore.Functions.Notify("Tu Ubor está en camino 🚖", "success")

    CreateThread(function()
    Wait(5000)
    if tipo == "normal" then
        QBCore.Functions.Notify("La reputación del conductor parece ser de 3.5 de 5 ⭐", "primary")
    elseif tipo == "cuidadoso" then
        QBCore.Functions.Notify("La reputación del conductor parece ser de 4.5 de 5 ⭐", "primary")
    elseif tipo == "erratico" then
        QBCore.Functions.Notify("La reputación del conductor parece ser de 0.5 de 5 ⭐ - No le Funciona bien...", "error")
    elseif tipo == "agresivo" then
        QBCore.Functions.Notify("La reputación del conductor parece ser de 2 de 5 ⭐ - Adicionales: Ex Piloto de Carreras Callejeras", "error")
    end
end)

-- Hilo llegada destino (mejorado)
CreateThread(function()
    local waitStart = nil
    local tripFinished = false
    while uborInProgress and DoesEntityExist(driver) and DoesEntityExist(veh) do
        Wait(1000)
        if hasStartedFinalTrip and not pendingPayment and not tripFinished then
            local vehPos = GetEntityCoords(veh)
            local dToDestino = #(vehPos - currentDestination)

            if not waitStart and dToDestino <= 50.0 then
                waitStart = GetGameTimer()
            end

            if dToDestino <= 15.0 or (waitStart and GetGameTimer() - waitStart > 40000) then
                -- Frenar vehículo
                TaskVehicleTempAction(driver, veh, 6, 5000)
                SetVehicleForwardSpeed(veh, 0.0)
                SetVehicleHandbrake(veh, true)
                SetVehicleEngineOn(veh, true, true, true)

                -- Calcular precio
                local currentPosition = GetEntityCoords(PlayerPedId())
                local distanceTraveled = calculateDistance(initialPlayerPosition, currentDestination)
                local price = Config.Pricing.basePrice + (distanceTraveled * Config.Pricing.pricePerMeter)
                price = math.max(Config.Pricing.minPrice, math.min(Config.Pricing.maxPrice, price))
                finalTripPrice = math.floor(price)

                pendingPayment = true
                tripFinished = true -- 🔹 evita que vuelva a entrar
                QBCore.Functions.Notify("Has llegado a tu destino. Presiona [E] para pagar $"..finalTripPrice, "primary")
            end
        end
    end
end)

    -- Hilo input pago
CreateThread(function()
    while true do
        Wait(0)
        if pendingPayment and DoesEntityExist(activeVehicle) then
            local vehPos = GetEntityCoords(activeVehicle)
            DrawText3D(vehPos.x, vehPos.y, vehPos.z + 1.5, "[E] Pagar viaje $"..finalTripPrice)
            if IsControlJustPressed(0, 38) then
                TriggerServerEvent('sh-ubor:server:PayTrip', finalTripPrice)
                pendingPayment = false
                Wait(3000)
                cleanupUber()
                break
            end
        end
    end
end)

-- Hilo para castigar si no paga (VERSIÓN CORREGIDA)
CreateThread(function()
    while uborInProgress and DoesEntityExist(activeDriver) do
        Wait(1000)

        if pendingPayment then
            if not IsPedInVehicle(PlayerPedId(), activeVehicle, false) then
                local t0 = GetGameTimer()
                while GetGameTimer() - t0 < 3000 and pendingPayment do
                    Wait(500)
                end

                if pendingPayment then
                    -- Chofer quieto
                    TaskLeaveVehicle(activeDriver, activeVehicle, 0)
                    ClearPedTasksImmediately(activeDriver)

                    -- Spawnear matones desde config (en círculo, SIEMPRE 3)
                    local spawnedThugs = {}
                    local playerPos = GetEntityCoords(PlayerPedId())

                    for i = 1, Config.Thugs.count do
                        local pedModel = joaat(Config.Thugs.models[math.random(1, #Config.Thugs.models)])
                        local weapon = joaat(Config.Thugs.weapons[math.random(1, #Config.Thugs.weapons)])

                        RequestModel(pedModel)
                        while not HasModelLoaded(pedModel) do Wait(10) end

                        -- Generar ángulo y distancia radial (círculo alrededor del jugador)
                        local angle = math.rad((360 / Config.Thugs.count) * i)
                        local spawnX = playerPos.x + math.cos(angle) * math.random(4,6)
                        local spawnY = playerPos.y + math.sin(angle) * math.random(4,6)
                        local spawnZ = playerPos.z

                        local thug = CreatePed(4, pedModel, spawnX, spawnY, spawnZ, 0.0, true, true)
                        PlaceObjectOnGroundProperly(thug)

                        SetBlockingOfNonTemporaryEvents(thug, true)
                        SetPedKeepTask(thug, true)
                        GiveWeaponToPed(thug, weapon, 1, false, true)
                        TaskCombatPed(thug, PlayerPedId(), 0, 16)
                        SetEntityAsMissionEntity(thug, true, true)

                        table.insert(spawnedThugs, thug)
                        SetModelAsNoLongerNeeded(pedModel)
                    end

                    QBCore.Functions.Notify("¡El conductor llamó a sus amigos y vienen a golpearte por no pagar!", "error")
                    pendingPayment = false

                    -- Hilo muerte/supervivencia
                    CreateThread(function()
    local startTime = GetGameTimer()
    local alertSent = false
    while uborInProgress do
        Wait(1000)

        -- ⚰️ Jugador muere
        if IsEntityDead(PlayerPedId()) and not alertSent then
            alertSent = true
            local halfPrice = math.floor(finalTripPrice / 2)
            TriggerServerEvent("sh-ubor:server:ForcePay", halfPrice)
            QBCore.Functions.Notify("Has muerto... El conductor te robó $"..halfPrice.." 💸", "error")

            -- Aviso a la policía con coords exactas
            local p = GetEntityCoords(PlayerPedId())
            TriggerServerEvent("sh-ubor:server:PoliceNotify", {
                msg = "Al parecer un pasajero descontento no quiso pagar su viaje y fue molido a golpes por el chofer y sus compañeros.",
                x = p.x, y = p.y, z = p.z
            })

            -- Esperar 5s antes de limpiar
            Wait(5000)
                                
                                -- Limpiar matones
                                for _, thug in ipairs(spawnedThugs) do
                                    if DoesEntityExist(thug) then 
                                        SetEntityAsMissionEntity(thug, false, true)
                                        DeleteEntity(thug) 
                                    end
                                end
                                
                                -- Limpiar conductor y vehículo (CORRECCIÓN IMPORTANTE)
                                if DoesEntityExist(activeDriver) then 
                                    SetEntityAsMissionEntity(activeDriver, false, true)
                                    DeleteEntity(activeDriver) 
                                end
                                
                                if DoesEntityExist(activeVehicle) then 
                                    SetEntityAsMissionEntity(activeVehicle, false, true)
                                    DeleteEntity(activeVehicle) 
                                end
                                
                                -- Limpieza completa del estado
                                cleanupUber(true)
                                break
                            end

                            -- ⏱️ Si pasan 60s y sigues vivo
                            if GetGameTimer() - startTime > 60000 then
                                QBCore.Functions.Notify("Los matones se cansaron y se fueron...", "success")

                                -- Limpiar matones
                                for _, thug in ipairs(spawnedThugs) do
                                    if DoesEntityExist(thug) then 
                                        SetEntityAsMissionEntity(thug, false, true)
                                        DeleteEntity(thug) 
                                    end
                                end
                                
                                -- Limpiar conductor y vehículo
                                if DoesEntityExist(activeDriver) then 
                                    SetEntityAsMissionEntity(activeDriver, false, true)
                                    DeleteEntity(activeDriver) 
                                end
                                
                                if DoesEntityExist(activeVehicle) then 
                                    SetEntityAsMissionEntity(activeVehicle, false, true)
                                    DeleteEntity(activeVehicle) 
                                end
                                
                                -- Limpieza completa del estado
                                cleanupUber(true)
                                break
                            end
                        end
                    end)

                    break
                end
            end
        end
    end
end)

-- 📡 Evento que reciben los policías para ver el blip
RegisterNetEvent("sh-ubor:client:PoliceBlip", function(msg, coords)
    if not coords or not coords.x then return end

    -- Blip exacto en coords
    local blip = AddBlipForCoord(coords.x+0.0, coords.y+0.0, coords.z+0.0)
    SetBlipSprite(blip, 161)       -- Ícono “alerta”
    SetBlipScale(blip, 1.2)
    SetBlipColour(blip, 1)         -- Rojo
    SetBlipAsShortRange(blip, false)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Agresión de chofer (Ubor)")
    EndTextCommandSetBlipName(blip)
    PulseBlip(blip)

    -- Sonido de radio
    PlaySoundFrontend(-1, "Start_Squelch", "CB_RADIO_SFX", true)

    -- Notify policial
    QBCore.Functions.Notify(msg, "primary", 8000)

    -- Quitar blip tras 90s
    CreateThread(function()
        Wait(90000)
        if DoesBlipExist(blip) then RemoveBlip(blip) end
    end)
end)

-- =========================================================
-- 🔻 Esto va DENTRO de tu function spawnUber(), al final
--     (después de crear driver/veh y setear variables)
-- =========================================================

-- Hilo llegada al jugador (fusionado con pasajeros cercanos)
CreateThread(function()
    local hasReachedPlayer = false

    while uborInProgress and DoesEntityExist(activeDriver) and DoesEntityExist(activeVehicle) do
        Wait(0)

        local driverPos = GetEntityCoords(activeDriver)
        if not hasReachedPlayer then
            local playerPosNow = GetEntityCoords(PlayerPedId())
            local d = #(driverPos - playerPosNow)

            if d <= Config.ArrivalDistance then
                hasReachedPlayer = true
                waitingForPlayer = true
                showInteraction = true

                -- Frenar Uber al llegar
                TaskVehicleTempAction(activeDriver, activeVehicle, 6, 5000)
                SetVehicleForwardSpeed(activeVehicle, 0.0)
                SetVehicleHandbrake(activeVehicle, true)

                QBCore.Functions.Notify("¡Tu Ubor llegó! Presiona [E] para subirte o [F] para meter al más cercano", "primary")

                local waitStartTime = GetGameTimer()
                local hasPlayerSubido = false

                while GetGameTimer() - waitStartTime < 30000 and not hasPlayerSubido and DoesEntityExist(activeVehicle) do
                    Wait(0)
                    local vehPos = GetEntityCoords(activeVehicle)

                    -- Mostrar opciones
                    DrawText3D(vehPos.x, vehPos.y, vehPos.z + 1.5, "[E] Subir al Ubor | [F] Subir al más cercano")

                    -- 🚖 El que pidió el Uber sube con E
                    if IsControlJustPressed(0, 38) then
                        if forcePlayerIntoVehicle() then
                            hasPlayerSubido = true
                            waitingForPlayer = false
                            showInteraction = false
                            initialPlayerPosition = GetEntityCoords(PlayerPedId())

                            QBCore.Functions.Notify("¡Bienvenido! Viajando...", "success")
                            SetVehicleHandbrake(activeVehicle, false)
                            driveTo(
                                activeDriver,
                                activeVehicle,
                                currentDestination.x,
                                currentDestination.y,
                                currentDestination.z,
                                currentSpeed,
                                currentDriveStyle
                            )
                            hasStartedFinalTrip = true
                        else
                            QBCore.Functions.Notify("Acércate más al vehículo.", "error")
                        end
                    end

                    -- 👥 Forzar a subir al más cercano con F
                    if IsControlJustPressed(0, 23) then
                        local closestPlayer, closestDist = QBCore.Functions.GetClosestPlayer()
                        if closestPlayer ~= -1 and closestDist < 3.0 then
                            local targetId = GetPlayerServerId(closestPlayer)
                            TriggerServerEvent("sh-ubor:server:ForcePassenger", targetId, VehToNet(activeVehicle))
                        else
                            QBCore.Functions.Notify("No hay nadie lo suficientemente cerca.", "error")
                        end
                    end
                end -- while de espera

                if not hasPlayerSubido then
                    QBCore.Functions.Notify("El conductor se fue porque no subiste a tiempo.", "error")
                    cleanupUber()
                end
            end -- if distancia
        end -- if not hasReachedPlayer
    end -- while principal
end) -- fin del hilo

return true
end -- 👈 cierra correctamente tu function spawnUber()


-- =========================================================
-- 🔺 Desde aquí EN ADELANTE va FUERA de la function spawnUber()
--     (ámbito global del client.lua)
-- =========================================================

-- 📌 Evento: el otro jugador se mete al vehículo cuando recibe la orden
RegisterNetEvent("sh-ubor:client:ForcePassenger", function(vehNet)
    local veh = NetToVeh(vehNet)
    if DoesEntityExist(veh) then
        local seats = {1, 2, 3}
        for _, seat in ipairs(seats) do
            if IsVehicleSeatFree(veh, seat) then
                TaskWarpPedIntoVehicle(PlayerPedId(), veh, seat)
                QBCore.Functions.Notify("Fuiste subido al Ubor por tu compañero", "success")

                -- 🔹 Sincronizar estado básico en el cliente pasajero
                activeVehicle = veh
                uborInProgress = true
                pendingPayment = false
                break
            end
        end
    end
end)

-- 📌 Evento forzar limpieza (desde server si muere o no paga el dueño)
RegisterNetEvent("sh-ubor:client:ForceCleanup", function()
    if uborInProgress then
        cleanupUber(true)
    end
end)

-- 📌 Limpieza completa de Uber
function cleanupUber(force)
    if activeDriver and DoesEntityExist(activeDriver) then
        DeletePed(activeDriver)
    end

    if activeVehicle and DoesEntityExist(activeVehicle) then
        DeleteVehicle(activeVehicle)
    end

    if activeBlip and DoesBlipExist(activeBlip) then
        RemoveBlip(activeBlip)
    end

    -- 🔄 Resetear todas las variables globales
    activeDriver = nil
    activeVehicle = nil
    activeBlip = nil
    uborInProgress = false
    currentDestination = nil
    currentDriveStyle = nil
    currentSpeed = nil
    waitingForPlayer = false
    showInteraction = false
    travelDistance = 0
    initialPlayerPosition = nil
    hasStartedFinalTrip = false
    pendingPayment = false
    finalTripPrice = 0

    if force then
        QBCore.Functions.Notify("El Uber fue cancelado.", "error")
    end
end

-- 📌 Evento: el otro jugador se mete al vehículo cuando recibe la orden
RegisterNetEvent("sh-ubor:client:ForcePassenger", function(vehNet)
    local veh = NetToVeh(vehNet)
    if DoesEntityExist(veh) then
        local seats = {1, 2, 3}
        for _, seat in ipairs(seats) do
            if IsVehicleSeatFree(veh, seat) then
                TaskWarpPedIntoVehicle(PlayerPedId(), veh, seat)
                QBCore.Functions.Notify("Fuiste subido al Ubor por tu compañero", "success")
                break
            end
        end
    end
end)

-- Comando /ubor
RegisterCommand(Config.CommandName, function()
    if uborInProgress then
        QBCore.Functions.Notify("Ya tienes un Ubor en camino.", "error")
        return
    end
    local success = spawnUber()
    if not success then
        uborInProgress = false
    end
end, false)

-- Cleanup
AddEventHandler('onResourceStop', function(resName)
    if resName == GetCurrentResourceName() then
        cleanupUber()
    end
end)
